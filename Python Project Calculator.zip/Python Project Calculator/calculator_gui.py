import tkinter as tk
from tkinter import messagebox
import math

# --- Round-off logic ---
def custom_round(value):
    try:
        float_val = float(value)
        decimal_part = float_val - int(float_val)

        if decimal_part > 0.5:
            result = math.ceil(float_val)
            condition = "Greater than 5 after the point."
        elif decimal_part < 0.5:
            result = math.floor(float_val)
            condition = "Less than 5 after the point."
        else:
            result = round(float_val)
            condition = "Equal to 5 after the point."

        display_result(f"{result} ({condition})")

    except ValueError:
        display_result("Invalid input")

# --- Core calculator logic ---
def calculate(operator):
    try:
        expression = entry.get()

        if operator == "sin":
            result = math.sin(math.radians(float(expression)))
        elif operator == "cos":
            result = math.cos(math.radians(float(expression)))
        elif operator == "tan":
            result = math.tan(math.radians(float(expression)))
        elif operator == "%":
            result = float(expression) / 100
        elif operator == "x^y":
            nums = expression.split('^')
            if len(nums) == 2:
                result = float(nums[0]) ** float(nums[1])
            else:
                display_result("Use x^y format")
                return
        else:
            result = eval(expression)

        display_result(result)

    except Exception as e:
        display_result("Error")

# --- Display result ---
def display_result(value):
    result_label.config(text=f"Result: {value}")

# --- Clear input ---
def clear():
    entry.delete(0, tk.END)
    result_label.config(text="Result:")

# --- GUI Setup ---
root = tk.Tk()
root.title("Advanced GUI Calculator")
root.geometry("400x500")
root.resizable(False, False)

entry = tk.Entry(root, font=("Arial", 20), borderwidth=3, relief="sunken")
entry.pack(pady=20, padx=10, fill='x')

result_label = tk.Label(root, text="Result:", font=("Arial", 16))
result_label.pack(pady=10)

# --- Button Frame ---
btn_frame = tk.Frame(root)
btn_frame.pack()

buttons = [
    ('7', lambda: entry.insert(tk.END, '7')), 
    ('8', lambda: entry.insert(tk.END, '8')),
    ('9', lambda: entry.insert(tk.END, '9')), 
    ('+', lambda: entry.insert(tk.END, '+')),
    
    ('4', lambda: entry.insert(tk.END, '4')), 
    ('5', lambda: entry.insert(tk.END, '5')),
    ('6', lambda: entry.insert(tk.END, '6')), 
    ('-', lambda: entry.insert(tk.END, '-')),
    
    ('1', lambda: entry.insert(tk.END, '1')), 
    ('2', lambda: entry.insert(tk.END, '2')),
    ('3', lambda: entry.insert(tk.END, '3')), 
    ('', lambda: entry.insert(tk.END, '')),

    ('0', lambda: entry.insert(tk.END, '0')), 
    ('.', lambda: entry.insert(tk.END, '.')),
    ('/', lambda: entry.insert(tk.END, '/')),
    ('^', lambda: entry.insert(tk.END, '^')),
]

for idx, (text, cmd) in enumerate(buttons):
    tk.Button(btn_frame, text=text, width=5, height=2, font=("Arial", 14), command=cmd).grid(row=idx//4, column=idx%4, padx=5, pady=5)

# --- Functional Buttons ---
func_frame = tk.Frame(root)
func_frame.pack(pady=10)

tk.Button(func_frame, text="sin", width=7, command=lambda: calculate("sin")).grid(row=0, column=0, padx=5)
tk.Button(func_frame, text="cos", width=7, command=lambda: calculate("cos")).grid(row=0, column=1, padx=5)
tk.Button(func_frame, text="tan", width=7, command=lambda: calculate("tan")).grid(row=0, column=2, padx=5)
tk.Button(func_frame, text="%", width=7, command=lambda: calculate("%")).grid(row=0, column=3, padx=5)
tk.Button(func_frame, text="x^y", width=7, command=lambda: calculate("x^y")).grid(row=1, column=0, padx=5, pady=5)
tk.Button(func_frame, text="=", width=7, command=lambda: calculate("eval")).grid(row=1, column=1, padx=5, pady=5)
tk.Button(func_frame, text="Round Off", width=15, command=lambda: custom_round(entry.get())).grid(row=1, column=2, columnspan=2, padx=5, pady=5)
tk.Button(root, text="Clear", font=("Arial", 12), command=clear).pack(pady=10)

root.mainloop()